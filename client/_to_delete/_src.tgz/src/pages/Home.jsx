import { useNavigate } from "react-router-dom";
import ThoughtflowsMedicalCodingHero from "@/components/ui/thoughtflows-medical-coding-hero";
import JourneyIntroSection from "../components/sections/JourneyIntroSection";
import WelcomeSection from "../components/sections/WelcomeSection";
import CoursesPreview from "../components/sections/CoursesPreview";
import BranchesPreview from "../components/sections/BranchesPreview";
import ImpactStats from "../components/sections/ImpactStats";
import WhyChooseUs from "../components/sections/WhyChooseUs";
import TestimonialsSection from "../components/sections/TestimonialsSection";
import FaqSection from "../components/sections/FaqSection";
import CTASection from "../components/sections/CTASection";
import { homeFaqs } from "../config/pageFaqs";
import { BRANCHES } from "../data/branches";

// Branch data flows in from the site's data layer — never hardcoded in the hero.
const heroBranches = BRANCHES.map((b) => ({ name: b.name, city: b.city }));

export default function Home() {
  const navigate = useNavigate();

  return (
    <>
      <ThoughtflowsMedicalCodingHero
        branches={heroBranches}
        branchCount={15}
        onNavigate={navigate}
        nextSectionId="journey"
      />
      <JourneyIntroSection id="journey" />
      <WelcomeSection />
      <CoursesPreview />
      <BranchesPreview />
      <ImpactStats />
      <WhyChooseUs />
      <TestimonialsSection />
      <FaqSection items={homeFaqs} />
      <CTASection />
    </>
  );
}
