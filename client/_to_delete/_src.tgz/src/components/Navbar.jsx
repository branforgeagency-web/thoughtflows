import { useEffect, useState, useRef } from "react";
import { Link, NavLink, useLocation } from "react-router-dom";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, X, ChevronRight, ChevronDown, Search, Phone, Sparkles } from "lucide-react";
import MagneticButton from "./MagneticButton";
import CourseSearchModal from "./CourseSearchModal";

const courseMegaMenuData = [
  {
    category: "AAPC",
    items: [
      { name: "CPC", slug: "cpc-certification" },
      { name: "CIC", slug: "cic-certification" },
      { name: "COC", slug: "coc-certification" },
      { name: "CPMA", slug: "cpma-certification" },
      { name: "CRC", slug: "hcc-risk-adjustment" },
      { name: "CPB", slug: "medical-billing-denial-management" },
      { name: "CEDC", slug: "cedc-certification" },
      { name: "CEMC", slug: "advanced-em-surgery-coding" },
      { name: "CDEO", slug: "cdeo-certification" },
      { name: "CDEI", slug: "cdei-certification" },
      { name: "CPPM", slug: "cppm-certification" }
    ]
  },
  {
    category: "SPECIALTY TRAINING",
    items: [
      { name: "SURGERY", slug: "advanced-em-surgery-coding" },
      { name: "ED", slug: "ed-coding" },
      { name: "EM", slug: "advanced-em-surgery-coding" },
      { name: "RADIOLOGY", slug: "radiology-coding" },
      { name: "ANESTHESIA", slug: "anesthesia-coding" },
      { name: "IP DRG", slug: "ccs-certification" },
      { name: "HCC", slug: "hcc-risk-adjustment" },
      { name: "IVR", slug: "ivr-coding" },
      { name: "CDI", slug: "cdi-coding" }
    ]
  },
  {
    category: "AHIMA",
    items: [
      { name: "CCS", slug: "ccs-certification" },
      { name: "CCS-P", slug: "ccs-p-certification" },
      { name: "RHIA", slug: "rhia-certification" },
      { name: "RHIT", slug: "rhit-certification" }
    ]
  },
  {
    category: "HIMAA",
    items: [
      { name: "CCC", slug: "ccc-certification" },
      { name: "HIM", slug: "him-certification" }
    ]
  }
];

const branchMenuData = [
  {
    name: "Coimbatore",
    hasSub: true,
    branches: [
      { name: "Gandhipuram", slug: "gandhipuram-coimbatore" },
      { name: "Hope College", slug: "hope-college-coimbatore" },
      { name: "Saravanampatti", slug: "saravanampatti-coimbatore" }
    ]
  },
  {
    name: "Kerala",
    hasSub: true,
    branches: [
      { name: "Kochi", slug: "kochi" },
      { name: "Trivandrum", slug: "trivandrum" }
    ]
  },
  {
    name: "Hyderabad",
    hasSub: true,
    branches: [
      { name: "Ameerpet", slug: "ameerpet-hyderabad" },
      { name: "Dilsukhnagar", slug: "dilsukhnagar-hyderabad" }
    ]
  },
  { name: "Tirupati", hasSub: false, slug: "tirupathi" },
  { name: "Trichy", hasSub: false, slug: "trichy" },
  { name: "Salem", hasSub: false, slug: "salem" },
  { name: "Vizag", hasSub: false, slug: "vizag" }
];

export default function Navbar() {
  const location = useLocation();
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [topBarVisible, setTopBarVisible] = useState(true);
  const [coursesHovered, setCoursesHovered] = useState(false);
  const [branchesHovered, setBranchesHovered] = useState(false);
  const [activeCitySub, setActiveCitySub] = useState(null);
  const [mobileCoursesOpen, setMobileCoursesOpen] = useState(false);
  const [mobileBranchesOpen, setMobileBranchesOpen] = useState(false);
  const coursesRef = useRef(null);
  const branchesRef = useRef(null);

  const isCoursesActive = location.pathname.startsWith("/courses");
  const isBranchesActive = location.pathname.startsWith("/branches");

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Close dropdowns when clicking outside
  useEffect(() => {
    const handleClickOutside = (e) => {
      if (coursesRef.current && !coursesRef.current.contains(e.target)) {
        setCoursesHovered(false);
      }
      if (branchesRef.current && !branchesRef.current.contains(e.target)) {
        setBranchesHovered(false);
        setActiveCitySub(null);
      }
    };
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <header
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        scrolled
          ? "bg-white/95 backdrop-blur-xl shadow-[0_4px_25px_-5px_rgba(6,59,122,0.08)] border-b border-[#063B7A]/8"
          : "bg-white/90 backdrop-blur-md border-b border-[#063B7A]/5 shadow-[0_2px_15px_-3px_rgba(6,59,122,0.03)]"
      }`}
    >
      {/* Top Announcement Bar */}
      {topBarVisible && (
        <div className="bg-gradient-to-r from-[#063B7A] via-[#0B4F9C] to-[#12BFD1] text-white text-xs font-semibold py-1.5 px-4 border-b border-white/10">
          <div className="container-max flex items-center justify-between gap-4">
            <div className="flex items-center gap-2.5 overflow-hidden whitespace-nowrap">
              <span className="bg-amber-400 text-slate-900 font-extrabold text-[10px] px-2 py-0.5 rounded-full uppercase tracking-wider shrink-0 shadow-xs">
                New Batch
              </span>
              <span className="truncate text-white/95 font-medium">
                🔥 Next AAPC CPC &amp; CIC Certification Batch Starts Monday! Limited Seats Available
              </span>
            </div>
            <div className="hidden sm:flex items-center gap-4 text-[11px] shrink-0 font-bold">
              <a href="tel:+919876543210" className="flex items-center gap-1.5 hover:text-amber-300 transition-colors">
                <Phone size={12} />
                <span>+91 98765 43210</span>
              </a>
              <button
                type="button"
                onClick={() => setTopBarVisible(false)}
                className="opacity-70 hover:opacity-100 transition-opacity p-0.5"
                aria-label="Dismiss banner"
              >
                <X size={13} />
              </button>
            </div>
          </div>
        </div>
      )}

      <nav className="container-max flex flex-row flex-nowrap items-center justify-between gap-4 md:gap-6 px-6 sm:px-8 lg:px-12 py-3.5">
        {/* Brand Logo */}
        <Link
          to="/"
          className="flex items-center shrink-0 hover:opacity-90 transition-opacity whitespace-nowrap"
          onClick={() => setOpen(false)}
        >
          <img 
            src="/thoughtflows.png" 
            alt="Thoughtflows" 
            className="h-8 md:h-9 lg:h-10 w-auto object-contain transition-all duration-300" 
          />
        </Link>

        {/* Desktop Navigation Links */}
        <div className="hidden lg:flex flex-row items-center gap-6 xl:gap-8 shrink-0 flex-nowrap whitespace-nowrap font-nav">
          <NavLink
            to="/"
            className={({ isActive }) =>
              `relative py-1 text-base font-bold tracking-tight transition-colors ${
                isActive ? "text-[#12BFD1]" : "text-[#063B7A] hover:text-[#12BFD1]"
              }`
            }
          >
            {({ isActive }) => (
              <>
                <span>Home</span>
                {isActive && (
                  <motion.span
                    layoutId="navUnderline"
                    className="absolute -bottom-1 left-0 right-0 h-[3px] rounded-full bg-[#12BFD1]"
                    transition={{ type: "spring", stiffness: 380, damping: 30 }}
                  />
                )}
              </>
            )}
          </NavLink>

          <NavLink
            to="/about"
            className={({ isActive }) =>
              `relative py-1 text-base font-bold tracking-tight transition-colors ${
                isActive ? "text-[#12BFD1]" : "text-[#063B7A] hover:text-[#12BFD1]"
              }`
            }
          >
            {({ isActive }) => (
              <>
                <span>About us</span>
                {isActive && (
                  <motion.span
                    layoutId="navUnderline"
                    className="absolute -bottom-1 left-0 right-0 h-[3px] rounded-full bg-[#12BFD1]"
                    transition={{ type: "spring", stiffness: 380, damping: 30 }}
                  />
                )}
              </>
            )}
          </NavLink>

          {/* COURSES MEGA DROPDOWN MENU */}
          <div
            ref={coursesRef}
            className="relative flex items-center py-1"
            onMouseEnter={() => setCoursesHovered(true)}
            onMouseLeave={() => setCoursesHovered(false)}
          >
            <button
              type="button"
              onClick={() => setCoursesHovered(!coursesHovered)}
              className={`text-base font-bold tracking-tight transition-colors inline-flex items-center gap-1.5 py-1 cursor-pointer outline-none ${
                isCoursesActive || coursesHovered ? "text-[#12BFD1]" : "text-[#063B7A] hover:text-[#12BFD1]"
              }`}
            >
              <span>Courses</span>
              <ChevronDown size={14} className={`transition-transform duration-300 ${coursesHovered ? "rotate-180 text-[#12BFD1]" : ""}`} />
            </button>
            {(isCoursesActive || coursesHovered) && (
              <motion.span
                layoutId="navUnderline"
                className="absolute -bottom-1 left-0 right-0 h-[3px] rounded-full bg-[#12BFD1]"
                transition={{ type: "spring", stiffness: 380, damping: 30 }}
              />
            )}

            {/* Solid White Mega Dropdown Popup Panel */}
            <AnimatePresence>
              {coursesHovered && (
                <motion.div
                  initial={{ opacity: 0, y: 10, scale: 0.97 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 6, scale: 0.97 }}
                  transition={{ duration: 0.2, ease: "easeOut" }}
                  className="absolute left-1/2 -translate-x-1/2 top-full pt-3 z-50 w-[720px] lg:w-[800px]"
                >
                  <div className="bg-white rounded-3xl shadow-[0_25px_60px_rgba(6,59,122,0.12)] p-7 border border-[#12BFD1]/20 grid grid-cols-4 gap-7 text-[#243447]">
                    {courseMegaMenuData.map((cat) => (
                      <div key={cat.category} className="flex flex-col">
                        <div className="border-b-2 border-[#12BFD1] pb-2 font-display font-extrabold text-xs uppercase tracking-wider text-[#063B7A] mb-3.5">
                          {cat.category}
                        </div>
                        <div className="space-y-2 flex-1 font-nav">
                          {cat.items.map((item) => (
                            <Link
                              key={item.name}
                              to={`/courses/${item.slug}`}
                              onClick={() => setCoursesHovered(false)}
                              className="block text-xs font-bold text-[#243447] hover:text-[#12BFD1] hover:translate-x-1 transition-all py-1 tracking-wide"
                            >
                              {item.name}
                            </Link>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          {/* BRANCHES DROPDOWN MENU */}
          <div
            ref={branchesRef}
            className="relative flex items-center py-1"
            onMouseEnter={() => setBranchesHovered(true)}
            onMouseLeave={() => {
              setBranchesHovered(false);
              setActiveCitySub(null);
            }}
          >
            <button
              type="button"
              onClick={() => setBranchesHovered(!branchesHovered)}
              className={`text-base font-bold tracking-tight transition-colors inline-flex items-center gap-1.5 py-1 cursor-pointer outline-none ${
                isBranchesActive || branchesHovered ? "text-[#12BFD1]" : "text-[#063B7A] hover:text-[#12BFD1]"
              }`}
            >
              <span>Branches</span>
              <ChevronDown size={14} className={`transition-transform duration-300 ${branchesHovered ? "rotate-180 text-[#12BFD1]" : ""}`} />
            </button>
            {(isBranchesActive || branchesHovered) && (
              <motion.span
                layoutId="navUnderline"
                className="absolute -bottom-1 left-0 right-0 h-[3px] rounded-full bg-[#12BFD1]"
                transition={{ type: "spring", stiffness: 380, damping: 30 }}
              />
            )}

            {/* Main Branches Dropdown Popup */}
            <AnimatePresence>
              {branchesHovered && (
                <motion.div
                  initial={{ opacity: 0, y: 10, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: 6, scale: 0.95 }}
                  transition={{ duration: 0.2, ease: "easeOut" }}
                  className="absolute left-0 top-full pt-2 z-50 min-w-[220px]"
                >
                  <div className="bg-white rounded-2xl shadow-2xl p-2.5 border border-[#12BFD1]/20 space-y-1 relative font-nav">
                    {branchMenuData.map((item) => (
                      <div
                        key={item.name}
                        className="relative"
                        onMouseEnter={() => setActiveCitySub(item.name)}
                      >
                        {item.hasSub ? (
                          <div className="flex items-center justify-between px-4 py-2.5 rounded-xl text-[#063B7A] font-bold text-sm hover:bg-[#E7F9FB] hover:text-[#12BFD1] cursor-pointer transition-colors group">
                            <span>{item.name}</span>
                            <ChevronRight size={16} className="text-[#063B7A]/50 group-hover:text-[#12BFD1] group-hover:translate-x-0.5 transition-transform" />
                          </div>
                        ) : (
                          <Link
                            to={`/branches/${item.slug}`}
                            onClick={() => {
                              setBranchesHovered(false);
                              setActiveCitySub(null);
                            }}
                            className="flex items-center justify-between px-4 py-2.5 rounded-xl text-[#063B7A] font-bold text-sm hover:bg-[#E7F9FB] hover:text-[#12BFD1] transition-colors"
                          >
                            <span>{item.name}</span>
                          </Link>
                        )}

                        {/* Flyout Submenu for Cities with multiple branches */}
                        <AnimatePresence>
                          {item.hasSub && activeCitySub === item.name && (
                            <motion.div
                              initial={{ opacity: 0, x: 8 }}
                              animate={{ opacity: 1, x: 0 }}
                              exit={{ opacity: 0, x: 4 }}
                              transition={{ duration: 0.15 }}
                              className="absolute left-full top-0 ml-1.5 min-w-[210px] bg-white rounded-2xl shadow-2xl p-2.5 border border-[#12BFD1]/20 z-50 space-y-1 font-nav"
                            >
                              <div className="px-3 py-1 text-[10px] font-display font-extrabold uppercase text-[#12BFD1] tracking-wider border-b border-[#063B7A]/10 mb-1">
                                {item.name} Campuses
                              </div>
                              {item.branches.map((b) => (
                                <Link
                                  key={b.slug}
                                  to={`/branches/${b.slug}`}
                                  onClick={() => {
                                    setBranchesHovered(false);
                                    setActiveCitySub(null);
                                  }}
                                  className="block px-3.5 py-2 rounded-xl text-sm font-bold text-[#063B7A] hover:bg-[#E7F9FB] hover:text-[#12BFD1] transition-colors"
                                >
                                  {b.name}
                                </Link>
                              ))}
                            </motion.div>
                          )}
                        </AnimatePresence>
                      </div>
                    ))}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>

          <NavLink
            to="/placements"
            className={({ isActive }) =>
              `relative py-1 text-base font-bold tracking-tight transition-colors ${
                isActive ? "text-[#12BFD1]" : "text-[#063B7A] hover:text-[#12BFD1]"
              }`
            }
          >
            {({ isActive }) => (
              <>
                <span>Placements</span>
                {isActive && (
                  <motion.span
                    layoutId="navUnderline"
                    className="absolute -bottom-1 left-0 right-0 h-[3px] rounded-full bg-[#12BFD1]"
                    transition={{ type: "spring", stiffness: 380, damping: 30 }}
                  />
                )}
              </>
            )}
          </NavLink>

          <NavLink
            to="/blogs"
            className={({ isActive }) =>
              `relative py-1 text-base font-bold tracking-tight transition-colors ${
                isActive ? "text-[#12BFD1]" : "text-[#063B7A] hover:text-[#12BFD1]"
              }`
            }
          >
            {({ isActive }) => (
              <>
                <span>Blogs</span>
                {isActive && (
                  <motion.span
                    layoutId="navUnderline"
                    className="absolute -bottom-1 left-0 right-0 h-[3px] rounded-full bg-[#12BFD1]"
                    transition={{ type: "spring", stiffness: 380, damping: 30 }}
                  />
                )}
              </>
            )}
          </NavLink>

          <NavLink
            to="/contact"
            className={({ isActive }) =>
              `relative py-1 text-base font-bold tracking-tight transition-colors ${
                isActive ? "text-[#12BFD1]" : "text-[#063B7A] hover:text-[#12BFD1]"
              }`
            }
          >
            {({ isActive }) => (
              <>
                <span>Contact us</span>
                {isActive && (
                  <motion.span
                    layoutId="navUnderline"
                    className="absolute -bottom-1 left-0 right-0 h-[3px] rounded-full bg-[#12BFD1]"
                    transition={{ type: "spring", stiffness: 380, damping: 30 }}
                  />
                )}
              </>
            )}
          </NavLink>
        </div>

        {/* CTA & Search Buttons */}
        <div className="hidden lg:flex items-center gap-3 shrink-0 whitespace-nowrap">
          <button
            type="button"
            onClick={() => setSearchOpen(true)}
            className="flex items-center gap-2 px-3.5 py-2 rounded-full bg-slate-100 hover:bg-[#E7F9FB] text-[#063B7A] hover:text-[#12BFD1] border border-slate-200 hover:border-[#12BFD1]/30 transition-all font-semibold text-xs shadow-xs cursor-pointer"
            title="Search courses & branches (Ctrl+K)"
          >
            <Search size={15} className="text-[#12BFD1]" />
            <span>Search...</span>
            <kbd className="hidden xl:inline-block px-1.5 py-0.5 text-[10px] font-bold text-slate-400 bg-white rounded border border-slate-200 shadow-2xs">Ctrl+K</kbd>
          </button>

          <MagneticButton as={Link} to="/contact" className="!px-6 !py-3 text-sm font-extrabold whitespace-nowrap">
            Enroll Now
          </MagneticButton>
        </div>

        {/* Mobile Search & Hamburger Toggle Buttons */}
        <div className="lg:hidden flex items-center gap-2">
          <button
            type="button"
            onClick={() => setSearchOpen(true)}
            className="p-2 text-[#063B7A] hover:text-[#12BFD1] transition-colors"
            aria-label="Search courses"
          >
            <Search size={22} />
          </button>

          <button
            className="p-2 text-[#063B7A] hover:text-[#12BFD1] transition-colors"
            onClick={() => setOpen((o) => !o)}
            aria-label="Toggle menu"
          >
            {open ? <X size={26} /> : <Menu size={26} />}
          </button>
        </div>
      </nav>

      {/* Mobile Drawer Menu */}
      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="lg:hidden bg-white border-b border-slate-200 overflow-hidden mt-3 mx-4 rounded-3xl shadow-2xl max-h-[85vh] overflow-y-auto"
          >
            <div className="flex flex-col p-6 gap-3">
              <NavLink to="/" onClick={() => setOpen(false)} className="text-base font-extrabold text-navy-900 py-1">
                Home
              </NavLink>
              <NavLink to="/about" onClick={() => setOpen(false)} className="text-base font-extrabold text-navy-900 py-1">
                About us
              </NavLink>

              {/* Mobile Courses Accordion */}
              <div className="py-1">
                <button
                  type="button"
                  onClick={() => setMobileCoursesOpen(!mobileCoursesOpen)}
                  className="w-full flex items-center justify-between text-base font-extrabold text-navy-900 py-1 cursor-pointer"
                >
                  <span>Courses</span>
                  <ChevronDown size={18} className={`transition-transform ${mobileCoursesOpen ? "rotate-180 text-teal-600" : ""}`} />
                </button>

                {mobileCoursesOpen && (
                  <div className="pl-4 pt-2 space-y-3 border-l-2 border-teal-500 mt-2">
                    {courseMegaMenuData.map((cat) => (
                      <div key={cat.category} className="space-y-1">
                        <div className="text-xs font-extrabold uppercase text-teal-600 tracking-wider">
                          {cat.category}
                        </div>
                        <div className="grid grid-cols-2 gap-1.5 pl-1">
                          {cat.items.map((item) => (
                            <Link
                              key={item.name}
                              to={`/courses/${item.slug}`}
                              onClick={() => setOpen(false)}
                              className="text-xs font-bold text-navy-900/80 py-1 hover:text-teal-600"
                            >
                              {item.name}
                            </Link>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Mobile Branches Accordion */}
              <div className="py-1">
                <button
                  type="button"
                  onClick={() => setMobileBranchesOpen(!mobileBranchesOpen)}
                  className="w-full flex items-center justify-between text-base font-extrabold text-navy-900 py-1 cursor-pointer"
                >
                  <span>Branches</span>
                  <ChevronDown size={18} className={`transition-transform ${mobileBranchesOpen ? "rotate-180 text-teal-600" : ""}`} />
                </button>

                {mobileBranchesOpen && (
                  <div className="pl-4 pt-2 space-y-2 border-l-2 border-teal-500 mt-2">
                    {branchMenuData.map((item) => (
                      <div key={item.name} className="space-y-1">
                        {item.hasSub ? (
                          <div>
                            <div className="text-xs font-extrabold uppercase text-teal-600 tracking-wider mb-1 pt-1">
                              {item.name}
                            </div>
                            {item.branches.map((b) => (
                              <Link
                                key={b.slug}
                                to={`/branches/${b.slug}`}
                                onClick={() => setOpen(false)}
                                className="block text-sm font-bold text-navy-900/80 py-1 pl-2 hover:text-teal-600"
                              >
                                {b.name}
                              </Link>
                            ))}
                          </div>
                        ) : (
                          <Link
                            to={`/branches/${item.slug}`}
                            onClick={() => setOpen(false)}
                            className="block text-sm font-bold text-navy-900/80 py-1 hover:text-teal-600"
                          >
                            {item.name}
                          </Link>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </div>

              <NavLink to="/placements" onClick={() => setOpen(false)} className="text-base font-extrabold text-navy-900 py-1">
                Placements
              </NavLink>
              <NavLink to="/blogs" onClick={() => setOpen(false)} className="text-base font-extrabold text-navy-900 py-1">
                Blogs
              </NavLink>
              <NavLink to="/contact" onClick={() => setOpen(false)} className="text-base font-extrabold text-navy-900 py-1">
                Contact us
              </NavLink>

              <MagneticButton as={Link} to="/contact" onClick={() => setOpen(false)} className="mt-3 w-full justify-center">
                Enroll Now
              </MagneticButton>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      {/* Spotlight Search Modal */}
      <CourseSearchModal isOpen={searchOpen} onClose={() => setSearchOpen(false)} />
    </header>
  );
}
