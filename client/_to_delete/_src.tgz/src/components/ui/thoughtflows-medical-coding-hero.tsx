import * as React from "react";

/**
 * ThoughtflowsMedicalCodingHero
 * ------------------------------------------------------------------
 * Cinematic scroll-scrubbed video hero for Thoughtflows Medical Coding Academy.
 *
 * How the "lock" works:
 *   The section is taller than the viewport (100vh + scrubDistance). Its inner
 *   stage is `position: sticky`, so the hero visually stays pinned while the
 *   visitor scrolls through `scrubDistance` pixels. Scroll position inside that
 *   range maps 0 → 1 onto video.currentTime. When the range is exhausted the
 *   sticky stage releases and the page scrolls on naturally. Scrolling back up
 *   re-enters the range and scrubs in reverse. Nothing hijacks wheel/touch
 *   events, so the visitor can never be trapped.
 *
 * Performance:
 *   - All per-frame updates write directly to DOM refs inside a single
 *     requestAnimationFrame loop (zero React re-renders while scrolling).
 *   - The loop only runs while there is something to settle, and only while
 *     the hero is on screen.
 *   - Video is attached after first paint (idle), loaded as a Blob when
 *     possible so seeking is instant, with a direct-src fallback.
 *   - A smaller source is used on narrow screens.
 *
 * Fallbacks (static, fully readable hero with all messaging + CTAs):
 *   - prefers-reduced-motion
 *   - Save-Data / 2G connections (mobile)
 *   - video fails to load or decode
 */

/* ------------------------------------------------------------------ */
/* Types                                                              */
/* ------------------------------------------------------------------ */

export interface ThoughtflowsHeroBranch {
  name: string;
  city?: string;
}

export interface ThoughtflowsHeroProps {
  /** Desktop/laptop video source (scrub-optimised: short GOP, no audio). */
  videoSrc?: string;
  /** Lighter source used on screens below `mobileBreakpoint`. Falls back to videoSrc. */
  mobileVideoSrc?: string;
  /** Poster / fallback still. */
  posterSrc?: string;
  academyName?: string;
  /** Short positioning line shown next to the brand name. */
  tagline?: string;
  /** Opening headline (rendered as the page <h1>). */
  title?: string;
  /** Final reveal headline. Sentences split on "." onto their own lines. */
  subtitle?: string;
  /** Supporting copy under the final headline. */
  description?: string;
  branchCount?: number;
  /** Optional branch data (from CMS/API). Only city names are shown, never a full list. */
  branches?: ThoughtflowsHeroBranch[];
  primaryCtaText?: string;
  primaryCtaHref?: string;
  secondaryCtaText?: string;
  secondaryCtaHref?: string;
  /** Optional low-emphasis third action. Pass an empty string to hide. */
  tertiaryCtaText?: string;
  tertiaryCtaHref?: string;
  /** Scroll distance (px) that maps to the full video on desktop. */
  scrubDistance?: number;
  /** Multiplier applied to scrubDistance below the mobile breakpoint. */
  mobileScrubFactor?: number;
  mobileBreakpoint?: number;
  /** Force the static (non-scrubbing) hero on mobile. */
  disableScrubOnMobile?: boolean;
  /**
   * SPA navigation hook. When provided, CTA clicks call this instead of a full
   * page load (e.g. pass react-router's `navigate`). Anchors keep real hrefs.
   */
  onNavigate?: (href: string) => void;
  /** id of the element that follows the hero; used by the "skip intro" link. */
  nextSectionId?: string;
  className?: string;
}

/* ------------------------------------------------------------------ */
/* Helpers                                                            */
/* ------------------------------------------------------------------ */

const clamp = (v: number, min = 0, max = 1) => Math.min(max, Math.max(min, v));
/** Normalised position of `p` inside [start, end], clamped 0..1. */
const range = (p: number, start: number, end: number) => clamp((p - start) / (end - start));
/** Smooth ease-out for reveal curves. */
const easeOut = (t: number) => 1 - Math.pow(1 - t, 3);

const CHAPTERS = ["Learn", "Code", "Certify", "Career", "Thoughtflows"] as const;

type Mode = "scrub" | "static";

function prefersStaticHero(isMobile: boolean, disableScrubOnMobile: boolean): boolean {
  if (typeof window === "undefined") return false;
  if (window.matchMedia?.("(prefers-reduced-motion: reduce)").matches) return true;
  if (isMobile && disableScrubOnMobile) return true;
  const nav = navigator as Navigator & {
    connection?: { saveData?: boolean; effectiveType?: string };
  };
  const conn = nav.connection;
  if (conn?.saveData) return true;
  if (isMobile && conn?.effectiveType && /(^|-)2g$/.test(conn.effectiveType)) return true;
  return false;
}

function splitSentences(text: string): string[] {
  return text
    .split(".")
    .map((s) => s.trim())
    .filter(Boolean)
    .map((s) => `${s}.`);
}

function uniqueCities(branches?: ThoughtflowsHeroBranch[]): string[] {
  if (!branches?.length) return [];
  const seen = new Set<string>();
  for (const b of branches) {
    const city = (b.city ?? b.name).split(",")[0].trim();
    if (city) seen.add(city);
  }
  return Array.from(seen);
}

/* ------------------------------------------------------------------ */
/* Component                                                          */
/* ------------------------------------------------------------------ */

export function ThoughtflowsMedicalCodingHero({
  videoSrc = "/videos/thoughtflows-hero-1280.mp4",
  mobileVideoSrc = "/videos/thoughtflows-hero-854.mp4",
  posterSrc = "/videos/thoughtflows-hero-poster.jpg",
  academyName = "THOUGHTFLOWS",
  tagline = "Medical Coding Academy",
  title = "BUILD YOUR FUTURE IN MEDICAL CODING",
  subtitle = "Learn. Get Certified. Build Your Career.",
  description = "Industry-focused medical coding training designed to help you take the next step toward a successful healthcare career.",
  branchCount = 15,
  branches,
  primaryCtaText = "Explore Courses",
  primaryCtaHref = "/courses",
  secondaryCtaText = "Find a Branch",
  secondaryCtaHref = "/branches",
  tertiaryCtaText = "Start Your Career",
  tertiaryCtaHref = "/contact",
  scrubDistance = 3200,
  mobileScrubFactor = 0.65,
  mobileBreakpoint = 768,
  disableScrubOnMobile = false,
  onNavigate,
  nextSectionId = "journey",
  className = "",
}: ThoughtflowsHeroProps) {
  /* ---------------- refs ---------------- */
  const sectionRef = React.useRef<HTMLElement>(null);
  const stageRef = React.useRef<HTMLDivElement>(null);
  const videoRef = React.useRef<HTMLVideoElement>(null);
  const shadeRef = React.useRef<HTMLDivElement>(null);
  const brandRef = React.useRef<HTMLDivElement>(null);
  const isMobileRef = React.useRef(false);
  const openingRef = React.useRef<HTMLDivElement>(null);
  const hintRef = React.useRef<HTMLDivElement>(null);
  const finalRef = React.useRef<HTMLDivElement>(null);
  const branchRef = React.useRef<HTMLDivElement>(null);
  const ctaRef = React.useRef<HTMLDivElement>(null);
  const barRef = React.useRef<HTMLDivElement>(null);
  const chapterRefs = React.useRef<(HTMLLIElement | null)[]>([]);

  const target = React.useRef(0); // progress from scroll position
  const current = React.useRef(0); // smoothed progress actually rendered
  const raf = React.useRef<number | null>(null);
  const visible = React.useRef(true);
  const activeChapter = React.useRef(-1);
  const ctaLive = React.useRef(false);

  /* ---------------- state (changes rarely) ---------------- */
  const [isMobile, setIsMobile] = React.useState(false);
  const [mode, setMode] = React.useState<Mode>("scrub");
  const [videoReady, setVideoReady] = React.useState(false);
  const [navOffset, setNavOffset] = React.useState(0);

  const cities = React.useMemo(() => uniqueCities(branches), [branches]);
  const finalLines = React.useMemo(() => splitSentences(subtitle), [subtitle]);
  const effectiveScrub = Math.round(isMobile ? scrubDistance * mobileScrubFactor : scrubDistance);

  /* ---------------- environment detection ---------------- */
  React.useEffect(() => {
    const mqMobile = window.matchMedia(`(max-width: ${mobileBreakpoint - 1}px)`);
    const mqMotion = window.matchMedia("(prefers-reduced-motion: reduce)");
    const evaluate = () => {
      const mobile = mqMobile.matches;
      isMobileRef.current = mobile;
      setIsMobile(mobile);
      setMode(prefersStaticHero(mobile, disableScrubOnMobile) ? "static" : "scrub");
    };
    evaluate();
    mqMobile.addEventListener("change", evaluate);
    mqMotion.addEventListener("change", evaluate);
    return () => {
      mqMobile.removeEventListener("change", evaluate);
      mqMotion.removeEventListener("change", evaluate);
    };
  }, [mobileBreakpoint, disableScrubOnMobile]);

  /* Keep content clear of a fixed site header, if one exists. */
  React.useEffect(() => {
    const header = document.querySelector<HTMLElement>("body header");
    if (!header || getComputedStyle(header).position !== "fixed") return;
    const measure = () => setNavOffset(header.offsetHeight);
    measure();
    const ro = new ResizeObserver(measure);
    ro.observe(header);
    return () => ro.disconnect();
  }, []);

  /* ---------------- video loading (deferred, blob-first) ---------------- */
  React.useEffect(() => {
    if (mode !== "scrub") return;
    const video = videoRef.current;
    if (!video) return;

    const src = isMobile && mobileVideoSrc ? mobileVideoSrc : videoSrc;
    const controller = new AbortController();
    let objectUrl: string | null = null;
    let cancelled = false;

    const attach = (url: string) => {
      if (cancelled) return;
      video.src = url;
      video.load();
    };

    const start = async () => {
      try {
        const res = await fetch(src, { signal: controller.signal });
        if (!res.ok) throw new Error(String(res.status));
        const blob = await res.blob();
        objectUrl = URL.createObjectURL(blob);
        attach(objectUrl);
      } catch (err) {
        if ((err as Error)?.name === "AbortError") return;
        // Blob path unavailable (CORS, memory, etc.) — stream directly instead.
        video.preload = "auto";
        attach(src);
      }
    };

    type IdleWindow = Window & {
      requestIdleCallback?: (cb: () => void, opts?: { timeout: number }) => number;
      cancelIdleCallback?: (id: number) => void;
    };
    const w = window as IdleWindow;
    const idleId = w.requestIdleCallback
      ? w.requestIdleCallback(start, { timeout: 1200 })
      : window.setTimeout(start, 300);

    return () => {
      cancelled = true;
      controller.abort();
      if (w.cancelIdleCallback) w.cancelIdleCallback(idleId);
      else window.clearTimeout(idleId);
      video.removeAttribute("src");
      video.load();
      if (objectUrl) URL.revokeObjectURL(objectUrl);
      setVideoReady(false);
    };
  }, [mode, isMobile, videoSrc, mobileVideoSrc]);

  const handleLoadedData = React.useCallback(() => {
    const video = videoRef.current;
    if (!video) return;
    // iOS Safari only renders seeks after the element has "played" once.
    video
      .play()
      .then(() => video.pause())
      .catch(() => {})
      .finally(() => {
        setVideoReady(true);
        requestTick();
      });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const handleVideoError = React.useCallback(() => setMode("static"), []);

  /* ---------------- per-frame rendering ---------------- */
  const render = React.useCallback((p: number) => {
    // Opening title: fade, blur, scale and lift over the first ~22%.
    const o = easeOut(range(p, 0.02, 0.22));
    if (openingRef.current) {
      const s = openingRef.current.style;
      s.opacity = String(1 - o);
      s.transform = `translate3d(0, ${-64 * o}px, 0) scale(${1 + 0.08 * o})`;
      s.filter = o > 0.001 ? `blur(${12 * o}px)` : "none";
      s.visibility = o >= 0.999 ? "hidden" : "visible";
    }
    if (hintRef.current) hintRef.current.style.opacity = String(1 - range(p, 0, 0.05));

    // Cinematic shade deepens toward the end so the final message stays legible.
    if (shadeRef.current) shadeRef.current.style.opacity = String(0.72 + 0.23 * range(p, 0.68, 0.86));

    // Final message (~80–90%).
    const f = easeOut(range(p, 0.78, 0.9));
    if (finalRef.current) {
      const s = finalRef.current.style;
      s.opacity = String(f);
      s.transform = `translate3d(0, ${40 * (1 - f)}px, 0)`;
      s.filter = f < 0.999 ? `blur(${10 * (1 - f)}px)` : "none";
      s.visibility = f <= 0.001 ? "hidden" : "visible";
    }
    // Small screens: hand the top of the frame to the final message.
    if (brandRef.current) brandRef.current.style.opacity = isMobileRef.current ? String(1 - range(p, 0.72, 0.8)) : "1";
    const b = easeOut(range(p, 0.84, 0.94));
    if (branchRef.current) {
      branchRef.current.style.opacity = String(b);
      branchRef.current.style.transform = `translate3d(0, ${20 * (1 - b)}px, 0)`;
    }
    const c = easeOut(range(p, 0.88, 0.97));
    if (ctaRef.current) {
      ctaRef.current.style.opacity = String(c);
      ctaRef.current.style.transform = `translate3d(0, ${24 * (1 - c)}px, 0)`;
      const live = c > 0.6;
      if (live !== ctaLive.current) {
        ctaLive.current = live;
        ctaRef.current.style.pointerEvents = live ? "auto" : "none";
      }
    }

    // Journey rail.
    if (barRef.current) barRef.current.style.transform = `scaleX(${p})`;
    const idx = Math.min(CHAPTERS.length - 1, Math.floor(p * CHAPTERS.length));
    if (idx !== activeChapter.current) {
      activeChapter.current = idx;
      chapterRefs.current.forEach((el, i) => {
        if (el) el.dataset.state = i < idx ? "done" : i === idx ? "active" : "todo";
      });
    }

    // Video scrub.
    const video = videoRef.current;
    if (video && video.readyState >= 1 && Number.isFinite(video.duration) && video.duration > 0) {
      const t = p * Math.max(0, video.duration - 0.05);
      if (!video.seeking && Math.abs(video.currentTime - t) > 1 / 60) {
        video.currentTime = t;
      }
    }
  }, []);

  const loop = React.useCallback(() => {
    const diff = target.current - current.current;
    current.current = Math.abs(diff) < 0.0004 ? target.current : current.current + diff * 0.14;
    render(current.current);
    raf.current = current.current !== target.current && visible.current ? requestAnimationFrame(loop) : null;
  }, [render]);

  const readProgress = React.useCallback(() => {
    const section = sectionRef.current;
    const stage = stageRef.current;
    if (!section || !stage) return;
    const travel = section.offsetHeight - stage.offsetHeight;
    const top = section.getBoundingClientRect().top;
    target.current = travel > 0 ? clamp(-top / travel) : 0;
  }, []);

  const requestTick = React.useCallback(() => {
    readProgress();
    if (raf.current == null) raf.current = requestAnimationFrame(loop);
  }, [readProgress, loop]);

  React.useEffect(() => {
    if (mode !== "scrub") return;
    const section = sectionRef.current;
    if (!section) return;

    const io = new IntersectionObserver(
      ([entry]) => {
        visible.current = entry.isIntersecting;
        if (entry.isIntersecting) requestTick();
      },
      { rootMargin: "100px 0px" }
    );
    io.observe(section);

    const onScroll = () => {
      if (visible.current) requestTick();
    };
    window.addEventListener("scroll", onScroll, { passive: true });
    window.addEventListener("resize", onScroll);

    // Initial paint — also covers landing mid-hero (refresh / back navigation).
    readProgress();
    current.current = target.current;
    activeChapter.current = -1;
    ctaLive.current = false;
    render(current.current);

    return () => {
      io.disconnect();
      window.removeEventListener("scroll", onScroll);
      window.removeEventListener("resize", onScroll);
      if (raf.current != null) cancelAnimationFrame(raf.current);
      raf.current = null;
    };
  }, [mode, effectiveScrub, readProgress, requestTick, render]);

  /* ---------------- navigation + a11y helpers ---------------- */
  const navigate = (href: string) => (e: React.MouseEvent<HTMLAnchorElement>) => {
    if (!onNavigate || e.defaultPrevented || e.button !== 0 || e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;
    if (/^(https?:)?\/\//.test(href) || href.startsWith("#")) return;
    e.preventDefault();
    onNavigate(href);
  };

  /** Keyboard users tabbing into the CTAs jump straight to the revealed end state. */
  const revealOnFocus = () => {
    if (mode !== "scrub" || target.current >= 0.97) return;
    const section = sectionRef.current;
    const stage = stageRef.current;
    if (!section || !stage) return;
    const end = section.getBoundingClientRect().top + window.scrollY + section.offsetHeight - stage.offsetHeight;
    window.scrollTo({ top: end, behavior: "auto" });
  };

  const skipIntro = (e: React.MouseEvent<HTMLAnchorElement>) => {
    const next = document.getElementById(nextSectionId);
    if (!next) return;
    e.preventDefault();
    next.scrollIntoView({ behavior: mode === "static" ? "auto" : "smooth", block: "start" });
    next.focus({ preventScroll: true });
  };

  /* ---------------- render ---------------- */
  const isStatic = mode === "static";
  const sectionStyle = {
    "--tf-nav": `${navOffset}px`,
    height: isStatic ? undefined : `calc(100vh + ${effectiveScrub}px)`,
  } as React.CSSProperties;

  const branchLine = branchCount > 0 && (
    <div ref={branchRef} className="mt-6 flex flex-col items-center gap-2 sm:mt-10" style={isStatic ? undefined : { opacity: 0 }}>
      <p className="font-display text-[11px] font-semibold uppercase tracking-[0.32em] text-[#7FE3EE] sm:text-xs">
        {branchCount} Branches Across India
      </p>
      {cities.length > 0 && (
        <p className="hidden max-w-[34rem] text-sm text-white/60 sm:block">
          {cities.slice(0, 5).join(" · ")}
          {cities.length > 5 ? " & more" : ""}
        </p>
      )}
    </div>
  );

  const ctas = (
    <div
      ref={ctaRef}
      onFocusCapture={revealOnFocus}
      className="mt-6 flex w-full max-w-sm flex-col items-center gap-2.5 sm:mt-10 sm:w-auto sm:max-w-none sm:gap-3 sm:flex-row sm:justify-center"
      style={isStatic ? undefined : { opacity: 0, pointerEvents: "none" }}
    >
      <a
        href={primaryCtaHref}
        onClick={navigate(primaryCtaHref)}
        className="group inline-flex h-11 w-full items-center justify-center gap-2 rounded-full bg-white sm:h-12 px-7 font-display text-sm font-bold text-[#06213F] shadow-[0_12px_40px_-12px_rgba(18,191,209,0.55)] transition-[transform,background-color] duration-300 hover:-translate-y-0.5 hover:bg-[#E9FBFD] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#7FE3EE] focus-visible:ring-offset-2 focus-visible:ring-offset-[#06213F] sm:w-auto"
      >
        {primaryCtaText}
        <svg aria-hidden="true" viewBox="0 0 20 20" className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-0.5" fill="none" stroke="currentColor" strokeWidth="2">
          <path d="M4 10h11M11 5l5 5-5 5" strokeLinecap="round" strokeLinejoin="round" />
        </svg>
      </a>
      <a
        href={secondaryCtaHref}
        onClick={navigate(secondaryCtaHref)}
        className="inline-flex h-11 w-full items-center justify-center gap-2 rounded-full border sm:h-12 border-white/25 bg-white/[0.06] px-7 font-display text-sm font-semibold text-white backdrop-blur-md transition-colors duration-300 hover:border-white/45 hover:bg-white/[0.12] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#7FE3EE] focus-visible:ring-offset-2 focus-visible:ring-offset-[#06213F] sm:w-auto"
      >
        <svg aria-hidden="true" viewBox="0 0 20 20" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="1.8">
          <path d="M10 18s6-5.2 6-10a6 6 0 1 0-12 0c0 4.8 6 10 6 10Z" strokeLinejoin="round" />
          <circle cx="10" cy="8" r="2.2" />
        </svg>
        {secondaryCtaText}
      </a>
      {tertiaryCtaText && (
        <a
          href={tertiaryCtaHref}
          onClick={navigate(tertiaryCtaHref)}
          className="inline-flex h-10 items-center justify-center px-4 font-display sm:h-12 text-sm font-semibold text-white/75 underline-offset-4 transition-colors hover:text-white hover:underline focus-visible:rounded-full focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#7FE3EE]"
        >
          {tertiaryCtaText}
        </a>
      )}
    </div>
  );

  return (
    <section
      ref={sectionRef}
      aria-label={`${academyName} ${tagline}`}
      className={`relative w-full bg-[#061A33] ${isStatic ? "min-h-[100svh]" : ""} ${className}`}
      style={sectionStyle}
    >
      <div
        ref={stageRef}
        className={`${isStatic ? "relative min-h-[100svh]" : "sticky top-0 h-screen supports-[height:100svh]:h-[100svh]"} w-full overflow-hidden`}
      >
        {/* ---------- Media layer ---------- */}
        <div className="absolute inset-0" aria-hidden="true">
          <img
            src={posterSrc}
            alt=""
            decoding="async"
            fetchPriority="high"
            className={`absolute inset-0 h-full w-full object-cover transition-opacity duration-700 ${videoReady && !isStatic ? "opacity-0" : "opacity-100"}`}
          />
          {!isStatic && (
            <video
              ref={videoRef}
              muted
              playsInline
              disablePictureInPicture
              preload="metadata"
              poster={posterSrc}
              tabIndex={-1}
              onLoadedData={handleLoadedData}
              onError={handleVideoError}
              className={`absolute inset-0 h-full w-full object-cover transition-opacity duration-700 ${videoReady ? "opacity-100" : "opacity-0"}`}
            />
          )}
          {/* Navy grade + vignette + bottom blend into the next section */}
          <div
            ref={shadeRef}
            className="absolute inset-0 bg-[linear-gradient(180deg,rgba(6,26,51,0.78)_0%,rgba(6,26,51,0.45)_38%,rgba(6,26,51,0.6)_70%,#061A33_100%)]"
            style={{ opacity: isStatic ? 0.92 : 0.72 }}
          />
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,transparent_35%,rgba(3,13,28,0.55)_100%)]" />
          <div className="absolute inset-0 mix-blend-soft-light bg-[radial-gradient(60%_50%_at_75%_20%,rgba(18,191,209,0.35),transparent_70%)]" />
        </div>

        {/* ---------- Content layer ---------- */}
        <div className="relative z-10 flex h-full min-h-[inherit] flex-col pt-[var(--tf-nav)]">
          {/* Brand mark */}
          <div ref={brandRef} className="flex items-center justify-center gap-3 px-4 pt-5 sm:pt-8">
            <span className="h-px w-8 bg-gradient-to-r from-transparent to-[#7FE3EE]/70 sm:w-12" aria-hidden="true" />
            <p className="flex flex-col items-center gap-1 text-center font-display text-[11px] font-semibold uppercase tracking-[0.36em] text-white/85 sm:flex-row sm:gap-0 sm:text-xs">
              <span>{academyName}</span>
              <span className="mx-2 hidden text-[#7FE3EE] sm:inline" aria-hidden="true">·</span>
              <span className="text-[10px] tracking-[0.24em] text-white/60 sm:text-xs">{tagline}</span>
            </p>
            <span className="h-px w-8 bg-gradient-to-l from-transparent to-[#7FE3EE]/70 sm:w-12" aria-hidden="true" />
          </div>

          {isStatic ? (
            /* ----- Static hero: everything visible, nothing depends on motion ----- */
            <div className="flex flex-1 flex-col items-center justify-center px-4 py-12 text-center sm:px-6">
              <h1 className="mx-auto max-w-[15ch] font-display text-[clamp(2rem,6vw,4.25rem)] font-extrabold leading-[1.02] tracking-[-0.02em] text-white">
                {title}
              </h1>
              <p className="mt-6 font-display text-lg font-bold uppercase tracking-[0.08em] text-[#7FE3EE] sm:text-xl">
                {subtitle}
              </p>
              <p className="mx-auto mt-4 max-w-[38rem] text-[15px] leading-relaxed text-white/75 sm:text-base">{description}</p>
              {branchLine}
              {ctas}
            </div>
          ) : (
            /* ----- Scrub hero: two stacked scenes driven by progress ----- */
            <div className="relative flex-1">
              {/* Opening scene */}
              <div ref={openingRef} className="absolute inset-0 flex items-center justify-center px-4 will-change-[transform,opacity,filter] sm:px-6">
                <h1 className="mx-auto max-w-[15ch] text-center font-display text-[clamp(2.1rem,7vw,5.5rem)] font-extrabold leading-[1.02] tracking-[-0.025em] text-white [text-shadow:0_4px_40px_rgba(3,13,28,0.45)]">
                  {title}
                </h1>
              </div>

              {/* Scroll hint */}
              <div ref={hintRef} className="pointer-events-none absolute inset-x-0 bottom-20 flex flex-col items-center gap-3 sm:bottom-24" aria-hidden="true">
                <span className="font-display text-[10px] font-semibold uppercase tracking-[0.4em] text-white/60">Scroll to begin</span>
                <span className="relative h-10 w-px overflow-hidden bg-white/15">
                  <span className="absolute inset-x-0 top-0 h-1/2 animate-[tf-hint_1.8s_ease-in-out_infinite] bg-[#7FE3EE]" />
                </span>
              </div>

              {/* Final scene */}
              <div
                ref={finalRef}
                className="absolute inset-0 flex flex-col items-center justify-center px-5 pb-12 text-center sm:pb-16 will-change-[transform,opacity,filter] sm:px-6"
                style={{ opacity: 0, visibility: "hidden" }}
              >
                <p className="font-display text-[clamp(1.75rem,6vw,4.5rem)] font-extrabold uppercase leading-[1.04] tracking-[-0.02em] text-white">
                  {finalLines.map((line, i) => (
                    <span key={line} className={`block ${i === finalLines.length - 1 ? "bg-gradient-to-r from-white via-[#C9F5FA] to-[#7FE3EE] bg-clip-text text-transparent" : ""}`}>
                      {line}
                    </span>
                  ))}
                </p>
                <p className="mx-auto mt-4 max-w-[36rem] text-sm leading-relaxed text-white/75 sm:mt-6 sm:text-base">{description}</p>
                {branchLine}
                {ctas}
              </div>

              {/* Journey rail */}
              <div className="pointer-events-none absolute inset-x-0 bottom-6 px-6 sm:bottom-8" aria-hidden="true">
                <div className="mx-auto max-w-xl">
                  <div className="relative h-px w-full bg-white/15">
                    <div ref={barRef} className="absolute inset-0 origin-left bg-gradient-to-r from-[#12BFD1] to-white" style={{ transform: "scaleX(0)" }} />
                  </div>
                  <ol className="mt-3 hidden justify-between sm:flex">
                    {CHAPTERS.map((c, i) => (
                      <li
                        key={c}
                        ref={(el) => {
                          chapterRefs.current[i] = el;
                        }}
                        data-state="todo"
                        className="font-display text-[10px] font-semibold uppercase tracking-[0.28em] text-white/35 transition-colors duration-500 data-[state=active]:text-white data-[state=done]:text-white/60"
                      >
                        {c}
                      </li>
                    ))}
                  </ol>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Skip link for keyboard / screen-reader users */}
        {!isStatic && (
          <a
            href={`#${nextSectionId}`}
            onClick={skipIntro}
            className="sr-only z-20 rounded-full bg-white px-4 py-2 font-display text-sm font-semibold text-[#06213F] focus:not-sr-only focus:absolute focus:right-4 focus:top-[calc(var(--tf-nav)+1rem)]"
          >
            Skip intro
          </a>
        )}
      </div>

      <style>{`@keyframes tf-hint{0%{transform:translateY(-100%)}60%,100%{transform:translateY(200%)}}`}</style>
    </section>
  );
}

export default ThoughtflowsMedicalCodingHero;
