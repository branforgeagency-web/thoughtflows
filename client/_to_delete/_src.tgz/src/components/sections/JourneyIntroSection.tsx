import * as React from "react";

/**
 * Bridge section directly below ThoughtflowsMedicalCodingHero.
 * Starts on the hero's deep navy and dissolves into the site's light surface,
 * so the cinematic opening hands over to the regular page without a hard edge.
 */

interface Pillar {
  step: string;
  title: string;
  body: string;
}

export interface JourneyIntroSectionProps {
  id?: string;
  eyebrow?: string;
  heading?: string;
  message?: string;
  pillars?: Pillar[];
  className?: string;
}

const DEFAULT_PILLARS: Pillar[] = [
  {
    step: "01",
    title: "Learn from industry-focused trainers",
    body: "Build a strong foundation in anatomy, medical terminology and coding guidelines in a structured classroom setting.",
  },
  {
    step: "02",
    title: "Prepare for professional certifications",
    body: "Work through certification-oriented practice designed around CPC and other medical coding credentials.",
  },
  {
    step: "03",
    title: "Develop healthcare career skills",
    body: "Apply what you learn to real-world coding scenarios and get ready for your next step in the healthcare industry.",
  },
];

export default function JourneyIntroSection({
  id = "journey",
  eyebrow = "Thoughtflows Medical Coding Academy",
  heading = "YOUR JOURNEY INTO MEDICAL CODING STARTS HERE",
  message = "Learn from industry-focused trainers, prepare for professional certifications, and develop the skills needed to build a career in the healthcare industry.",
  pillars = DEFAULT_PILLARS,
  className = "",
}: JourneyIntroSectionProps) {
  const headingId = `${id}-heading`;

  return (
    <section
      id={id}
      tabIndex={-1}
      aria-labelledby={headingId}
      className={`relative overflow-hidden bg-[linear-gradient(180deg,#061A33_0%,#0A2B52_34%,#F8FCFD_78%)] px-4 pb-20 pt-20 outline-none sm:px-8 sm:pb-28 sm:pt-28 lg:px-12 ${className}`}
    >
      {/* Soft teal light carried over from the hero */}
      <div
        aria-hidden="true"
        className="pointer-events-none absolute left-1/2 top-0 h-[420px] w-[820px] max-w-[140vw] -translate-x-1/2 rounded-full bg-[#12BFD1]/15 blur-[120px]"
      />

      <div className="container-max relative">
        <div className="mx-auto max-w-3xl text-center">
          <p className="font-display text-[11px] font-semibold uppercase tracking-[0.32em] text-[#7FE3EE] sm:text-xs">{eyebrow}</p>
          <h2
            id={headingId}
            className="mt-5 font-display text-[clamp(1.75rem,4.6vw,3.25rem)] font-extrabold leading-[1.08] tracking-[-0.02em] !text-white"
          >
            {heading}
          </h2>
          <p className="mx-auto mt-5 max-w-2xl text-[15px] leading-relaxed text-white/75 sm:text-lg">{message}</p>
        </div>

        <ol className="mx-auto mt-14 grid max-w-6xl gap-4 sm:mt-16 md:grid-cols-3 md:gap-6">
          {pillars.map((p) => (
            <li
              key={p.step}
              className="group relative rounded-3xl border border-[#063B7A]/10 bg-white/90 p-7 shadow-[0_24px_60px_-28px_rgba(6,26,51,0.45)] backdrop-blur-xl transition-transform duration-500 hover:-translate-y-1 sm:p-8"
            >
              <span className="font-display text-xs font-bold tracking-[0.3em] text-[#0EA2B2]">{p.step}</span>
              <h3 className="mt-4 font-display text-lg font-bold leading-snug text-[#06213F] sm:text-xl">{p.title}</h3>
              <p className="mt-3 text-sm leading-relaxed text-[#334E68] sm:text-[15px]">{p.body}</p>
              <span
                aria-hidden="true"
                className="absolute inset-x-8 bottom-0 h-px origin-left scale-x-0 bg-gradient-to-r from-[#12BFD1] to-[#063B7A] transition-transform duration-500 group-hover:scale-x-100"
              />
            </li>
          ))}
        </ol>
      </div>
    </section>
  );
}
